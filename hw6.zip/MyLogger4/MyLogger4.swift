import Foundation

public struct MyLogger4 {
public static func log(_ s: String) {
         print("MyLogger4 from carthage (\(Date())): \(s)")
     }
}
