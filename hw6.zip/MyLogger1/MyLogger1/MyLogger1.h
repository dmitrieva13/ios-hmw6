//
//  MyLogger1.h
//  MyLogger1
//
//  Created by Varvara on 18.11.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for MyLogger1.
FOUNDATION_EXPORT double MyLogger1VersionNumber;

//! Project version string for MyLogger1.
FOUNDATION_EXPORT const unsigned char MyLogger1VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyLogger1/PublicHeader.h>


